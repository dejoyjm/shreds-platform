from decimal import Decimal
from django.db import transaction

from ..models import Response, ScoreReport, Test, Candidate, Question
from collections import defaultdict


@transaction.atomic
def calculate_score_for_candidate(test: Test, candidate: Candidate, attempt_number: int):
    print(f"\n🧠 Scoring for: {candidate.name} | Test: {test.name} | Attempt #{attempt_number}")

    responses = Response.objects.filter(
        candidate=candidate,
        test=test,
        attempt_number=attempt_number
    ).select_related('question__category')

    print(f"✅ Found {responses.count()} responses")

    total_score = Decimal('0.0')
    total_positive = Decimal('0.0')
    total_negative = Decimal('0.0')
    total_correct = 0
    total_wrong = 0
    total_unattempted = 0

    for r in responses:
        question = r.question
        submitted = (r.answer or "").strip().lower()
        correct = (question.correct_answer or "").strip().lower()

        if not submitted:
            total_unattempted += 1
            continue

        print(f"Q{question.id}: Submitted='{submitted}' | Correct='{correct}'")

        if submitted == correct:
            marks = Decimal(str(question.positive_marks or 1.0))
            total_score += marks
            total_positive += marks
            total_correct += 1
            print(f"✅ Correct (+{marks})")
        else:
            penalty = Decimal(str(question.negative_marks or 0.0))
            total_score -= penalty
            total_negative += penalty
            total_wrong += 1
            print(f"❌ Incorrect (-{penalty})")

    report, created = ScoreReport.objects.update_or_create(
        test=test,
        candidate=candidate,
        defaults={
            'score': total_score,
            'total_positive': total_positive,
            'total_negative': total_negative,
            'total_correct': total_correct,
            'total_wrong': total_wrong,
            'total_unattempted': total_unattempted,
        }
    )

    print(f"💾 Final Score: {total_score} / Max Possible: {total_positive + total_negative}")
    print(f"🟢 Correct: {total_correct}, 🔴 Wrong: {total_wrong}, ⚪ Unattempted: {total_unattempted}\n")

    return report

def serialize_score_report(report: ScoreReport) -> dict:
    test = report.test
    candidate = report.candidate

    # Base fields
    data = {
        "test_id": test.id,
        "candidate_id": candidate.id,
        "score": float(report.score),
        "max_score": float(report.max_score),
        "percentage": round((report.score / report.max_score) * 100, 2) if report.max_score else 0.0,
        "total_correct": report.total_correct,
        "total_wrong": report.total_wrong,
        "total_unattempted": report.total_unattempted,
        "category_summary": {},
    }

    # Category-wise breakdown
    category_data = defaultdict(lambda: {
        "score": 0,
        "correct": 0,
        "wrong": 0,
        "unattempted": 0,
        "max_score": 0,
    })

    responses = Response.objects.filter(candidate=candidate, test=test).select_related('question__category')


    for resp in responses:
        q = resp.question
        cat = q.category.name if q.category else "Uncategorized"
        max_marks = q.positive_marks
        category_data[cat]["max_score"] += max_marks

        if resp.answer.strip() == "":
            category_data[cat]["unattempted"] += 1
        elif resp.answer == q.correct_answer:
            category_data[cat]["correct"] += 1
            category_data[cat]["score"] += max_marks
        else:
            category_data[cat]["wrong"] += 1
            category_data[cat]["score"] -= q.negative_marks

    # Finalize category_summary
    for cat, stats in category_data.items():
        attempted = stats["correct"] + stats["wrong"]
        stats["percentage"] = round((stats["score"] / stats["max_score"] * 100), 2) if stats["max_score"] else 0.0
        data["category_summary"][cat] = stats

    return data


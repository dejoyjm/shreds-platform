// pages/_app.js
import '../src/styles/globals.css'

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
